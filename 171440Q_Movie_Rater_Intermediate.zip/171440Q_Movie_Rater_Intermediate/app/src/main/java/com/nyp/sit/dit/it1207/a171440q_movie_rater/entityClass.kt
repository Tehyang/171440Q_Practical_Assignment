package com.nyp.sit.dit.it1207.a171440q_movie_rater

class movieEntity {
    var reviewName: String = ""
    var reviewDesc: String = ""
    var reviewLang: String = ""
    var reviewRelDate: String = ""
    var reviewSuitAudience: String = ""
    var ratingBarForMovie: Float = -1F
    var ratingTextForMovie: String = ""
}

var instanceMovie = movieEntity()